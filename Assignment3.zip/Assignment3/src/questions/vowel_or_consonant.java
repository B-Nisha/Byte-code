//8.Write a program to input any alphabet and check whether it is vowel or consonant?


package questions;

public class vowel_or_consonant {

	public static void main(String[] args) {
		char ch='g';
		if (ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U') {
			System.out.println("it is a vowel");
		}
		else {
			System.out.println("it is a consonant");
		}
				

	}

}
