//1.Write a program to find maximum between two numbers?

package questions;

public class max_of_two {

	public static void main(String[] args) {
		int a=5,b=10;
	   
		if (a>b) {
			System.out.println("a");
			
		}
		else
		{
			System.out.println("b");
		}
			

	}

}
