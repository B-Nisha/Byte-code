//16.Write a program to calculate profit or loss?

package questions;

public class profit_or_loss {
	
	public static void main(String[] args) {
		int costprice=100, sellingprice=150;
		
		if (sellingprice > costprice) {
			System.out.println("profit");
		}
		else {
			System.out.println("loss");
		}

	}

}
