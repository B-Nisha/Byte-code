//4.Write a program to check whether a number is divisible by 5 and 11 or not?

package questions;

public class div_by_5and11 {

	public static void main(String[] args) {
		int a=10;
		if (a%5==0 && a%11==0)
		{
			System.out.println("divisible");
		}
		else {
			System.out.println("not divisible");
		}

	}

}
