package operators;

public class comparision {

	public static void main(String[] args) {
		int a=23,b=45;
		System.out.println("The given numbers are equal:"+(a==b));


		

	}

}
