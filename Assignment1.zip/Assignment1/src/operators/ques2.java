package operators;

public class ques2 {

	public static void main(String[] args) {
		int a=8,b=2345;
		int c=a+b;//2353
		int d=c/3;//784
		System.out.println("result:"+(d%5)*5);//20



	}

}
