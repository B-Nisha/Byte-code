package operators;

public class triangle_perimeter {

	public static void main(String[] args) {
		int a=2,b=3,c=5;
		System.out.println("perimeter of triangle :"+(a+b+c));//10



	}

}
