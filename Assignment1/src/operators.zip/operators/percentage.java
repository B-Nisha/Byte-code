package operators;

public class percentage {

	public static void main(String[] args) {
		int s1=78,s2=45,s3=62;
		float total = s1 + s2 + s3;//185.0
		float percentage = ((total/300)*100);//61.66
		System.out.println("robert's total marks:"+total);
		System.out.println("robert's percentage:"+percentage+"%");



	}

}
