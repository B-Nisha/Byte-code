package operators;

public class area_perimeter {

	public static void main(String[] args) {
		int l=5,b=7;
		System.out.println("The area of rectangle="+(l*b));//35
		System.out.println("The perimeter of rectangle="+(2*(l+b)));//24


	}

}
