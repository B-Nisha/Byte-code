//2.Write a program to find maximum between three numbers?

package questions;

public class Max_of_three {

	public static void main(String[] args) {
		int a=1,b=2,c=3;
		if (a>b) {
			if (a>c) {
				System.out.println("The max num is :"+"a");
			}
			
			else 
			{
				System.out.println("The max num is :"+"c");
			}
		
		}
		else {
			if (b>c) {
				System.out.println("The max num is :"+"b");
			}
			else {
				System.out.println("The max num is :"+"c");
			}
		}

	
		
				


	}

}
