//3.Write a program to check whether a number is negative, positive or zero?


package questions;

public class pos_neg_zero {

	public static void main(String[] args) {
		int a=0;
		if (a>0) {
			System.out.println("a is positive");
			
		}
		else if (a<0) {
				System.out.println("a is negitive");
			}
		else 
			
			System.out.println("zero");
		
		
		
	
	

	}

}
