//5.Write a program to check whether a number is even or odd?

package questions;

public class even_odd {

	public static void main(String[] args) {
		int a=5;
		if (a%2==0)
			System.out.println("even");
		else {
			System.out.println("odd");
		}

	}

}
