//7.Write a program to check whether a character is alphabet or not?


package questions;

public class alphabet_or_not {

	public static void main(String[] args) {
		char alpha='A';
		if (alpha>='a' || alpha>='A')
		{
			System.out.println("it is an alphabet");
		}
		else {
			System.out.println("not an alphabet");
		}
				
	

	}

}
